SET search_path TO objects;

create table users
(
    user_id   serial
        constraint users_pk
            primary key,
    user_name varchar not null
);

comment on table users is 'Пользователи';

comment on column users.user_id is 'PK';

comment on column users.user_name is 'Имя пользователя';

alter table users
    owner to postgres;

