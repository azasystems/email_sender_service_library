SET search_path TO objects;

create or replace procedure get_emails_to_validate(before_days integer)
    language plpgsql
as
$$
BEGIN
    SELECT e.email_id, email, user_id, s.validts
    FROM objects.subscriptions s
             JOIN objects.emails e on e.email_id = s.email_id
    WHERE (NOW() + before_days * (interval '1' DAY)) > s.validts;
END;
$$;

comment on procedure get_emails_to_validate(integer) is 'Получить все email истекающих подписок за before_days дней';
