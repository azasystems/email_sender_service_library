SET search_path TO objects;

drop table users;