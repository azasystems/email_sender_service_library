create database email_sender_service with owner postgres;
\connect email_sender_service;
SET search_path TO email_sender_service;
create schema objects;
create schema operations;
