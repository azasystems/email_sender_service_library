SET search_path TO objects;

create or replace procedure seed_test_subscriptions(subscriptions_number integer)
    language plpgsql
as
$$
BEGIN
    FOR i IN 1..subscriptions_number
        LOOP
            INSERT INTO objects.subscriptions (email_id, validts)
            VALUES (i, (NOW() + INTERVAL '30 DAYS'));
        END LOOP;
END;
$$;

comment on procedure seed_test_subscriptions(integer) is 'Заполнение таблицы Подписки (subscriptions) тестовыми данными';
