SET search_path TO operations;

drop table deadletter;
