drop schema objects;
drop schema operations;
drop database email_sender_service;